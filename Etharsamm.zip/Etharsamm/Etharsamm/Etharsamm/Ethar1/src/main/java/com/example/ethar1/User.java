package com.example.ethar1;

public class User {
    static String username;
    static String useremail;
    static String userpassword;
    static String usernameL;
    static String number;

    public static int getId() {
        return Id;
    }

    public static void setId(int id) {
        Id = id;
    }

    static int Id;

    public User() {
    }

    public static String getUseradd() {
        return useradd;
    }

    public static void setUseradd(String useradd) {
        User.useradd = useradd;
    }


    static String useradd;

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        User.username = username;
    }

    public static String getUseremail() {
        return useremail;
    }

    public static void setUseremail(String useremail) {
        User.useremail = useremail;
    }

    public static String getUserpassword() {
        return userpassword;
    }

    public static void setUserpassword(String userpassword) {
        User.userpassword = userpassword;
    }

    public static void setUsernameL(String usernameL) {
        User.usernameL = usernameL;
    }

    public static String getUsernameL() {
        return usernameL;
    }
}
