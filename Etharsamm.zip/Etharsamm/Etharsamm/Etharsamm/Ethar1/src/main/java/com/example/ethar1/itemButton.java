package com.example.ethar1;

import javafx.scene.image.ImageView;

public class itemButton {
    static Boolean womenButton;
    static Boolean menButton;
    static Boolean kidsButton;

//   static String itemw1;
//    static String itemw2;
//    static String itemw3;
//    static String itemw4;
//    static String itemw5;
//    static String itemw6;
//
//    static String itemm1;
//    static String itemm2;
//    static String itemm3;
//    static String itemm4;
//    static String itemm5;
//    static String itemm6;
//
//    static String itemk1;
//    static String itemk2;
//    static String itemk3;
}
