package com.example.ethar1;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.util.List;

import javafx.fxml.Initializable;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;

import java.io.IOException;
import java.util.ResourceBundle;

/**
 * FXML Controller class
 *
 * @author malia
 */
public class loginControlfordonee implements Initializable {
    @FXML
    private TextField pass;
    @FXML
    private TextField email;

    @FXML
    private Label emailero;

    @FXML
    private Button loginButton;

    @FXML
    private Label passeror;


    @FXML
    private Label signup;
Donee d2=new Donee();
boolean flag=false;
int id;
    @FXML

    public void signUp(MouseEvent mouseEvent) throws IOException {


        Parent sign = FXMLLoader.load(getClass().getResource("/sign.fxml"));
        Scene signScene = new Scene(sign);
        Stage stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        stage.setScene(signScene);
        stage.show();
}

//نحط شرط الدخول

@FXML

    public void login(MouseEvent event) throws IOException {
        Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<Donee> sList;
        Query query;
        query = session1.createQuery("from Donee");
        sList = query.list();
        session1.close();
        for (Donee u : sList) {
            u.getEmail();
            u.getPass();
        }
            //chick if the email has been used:
            for (Donee u : sList) {

                if (email.getText().equals(u.getEmail()) && pass.getText().equals(u.getPass())) {
                   flag=true;

                    User.setUseremail(u.getEmail());
                    User.setUsername(u.getFirstName());
                    User.setUsernameL(u.getLastName());
                    User.setUseradd((u.getAddress()));
                    User.setUserpassword(u.getPass());
                   User.setId(u.getDoneeId());
                    System.out.println(u.getDoneeId());
                    Parent LOG = FXMLLoader.load(getClass().getResource("/home.fxml"));
                    Scene homeScene = new Scene(LOG);
                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    stage.setScene(homeScene);
                    stage.show();

                }
                else {
                    if (!(email.getText().equals(u.getEmail())))
                        emailero.setText("البريد الالكتروني غير مسجل");

                    else{
                        emailero.setText("");
                        passeror.setText("كلمة المرور غير صحيحة");
                    }

                }

            }

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}

    /**
     * Initializes the controller class.
     */
    

