package com.example.ethar1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name="Category")
public class Category implements Serializable {

    @Id
    @Column(name = "CategoryID")
    private int CategoryID;
    @Column(name = "Section")
    private String Section;
    @Column(name = "Type1")
    private String Type1;

    public Category() {

    }

    public int getCategoryID() {
        return CategoryID;
    }

    public void setCategoryID(int categoryID) {
        CategoryID = categoryID;
    }

    public String getSection() {
        return Section;
    }

    public void setSection(String section) {
        Section = section;
    }

    public String getType1() {
        return Type1;
    }

    public void setType1(String type1) {
        Type1 = type1;
    }
}