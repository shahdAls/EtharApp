package com.example.ethar1;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.persistence.*;
import com.example.ethar1.Category;

@Entity
@Table(name="Item")
public class Item implements java.io.Serializable {
    private static int itemCounter = 900;

    @Id
    @Column(name = "ItemID")
    private int ItemID;
    @Column(name = "Descrip")
    private String Descrip;
    @Column(name = "amount")
    private int amount;
    @Column(name = "Size")
    private String Size;
    @Column(name = "Availability")
    private Boolean Availability;
    @Column(name = "Image")
    private String Image;

    @ManyToOne
    @JoinColumn(name = "CategoryID")
    private Category category;


    public Item() {
        Availability = true;
        itemCounter = (int) (Math.random() * (9999 - 1000 + 1) + 1000);
        ItemID = itemCounter;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public static int getItemCounter() {
        return itemCounter;
    }

    public static void setItemCounter(int itemCounter) {
        Item.itemCounter = itemCounter;
    }


    public int getItemID() {
        return ItemID;
    }

    public void setItemID(int itemID) {
        ItemID = itemID;
    }

    public String getDescrip() {
        return Descrip;
    }

    public void setDescrip(String descrip) {
        Descrip = descrip;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getSize() {
        return Size;
    }

    public void setSize(String size) {
        Size = size;
    }

    public Boolean getAvailability() {
        return Availability;
    }

    public void setAvailability(Boolean availability) {
        Availability = availability;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    @ManyToOne
    @JoinColumn(name = "DonorID")
    private Donor DonorID;

    public Donor getDonorID() {
        return DonorID;
    }

    public void setDonorID(Donor donorID) {
        DonorID = donorID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "Name1")
    private String name;


    public void setCategoryID(String gender, String type) {

        if (gender.equals("Women") & type.equals("dress")) {
            category.setCategoryID(1);
        } else if (gender.equals("Women") & type.equals("pants")) {
            category.setCategoryID(2);
        } else if (gender.equals("Women") &type.equals("shoes")) {
            category.setCategoryID(3);
        } else if (gender.equals("Women") & type.equals("shirt")) {
            category.setCategoryID(4);
        } else if (gender.equals("Men") & type.equals("shirt")) {
            category.setCategoryID(5);
        } else if (gender.equals("Men") & type.equals("pants")) {
            category.setCategoryID(6);
        } else if (gender.equals("Men") & type.equals("shoes")) {
            category.setCategoryID(7);
        } else if (gender.equals("Children") & type.equals("dress")) {
            category.setCategoryID(8);
        } else if (gender.equals("Children") & type.equals("pants")) {
            category.setCategoryID(9);
        } else if (gender.equals("Children") & type.equals("shoes")) {
            category.setCategoryID(10);
        } else if (gender.equals("Children") & type.equals("shirt")) {
            category.setCategoryID(11);
        } else if (gender.equals("Women") & type.equals("thob")) {
            category.setCategoryID(12);
        } else if (gender.equals("Men") & type.equals("thob")) {
            category.setCategoryID(13);
        } else if (gender.equals("Children") & type.equals("thob")) {
            category.setCategoryID(14);
        }
    }


}
