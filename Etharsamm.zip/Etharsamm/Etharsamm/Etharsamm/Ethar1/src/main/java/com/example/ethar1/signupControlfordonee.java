package com.example.ethar1;

import java.io.IOException;
import java.util.List;

import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import org.hibernate.Query;
import org.hibernate.Session;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import org.hibernate.Transaction;

public class signupControlfordonee {


    @FXML
    private TextField F_name;


    @FXML
    private TextField L_name;

    @FXML
    private TextField add;

    @FXML
    private TextField email;

    @FXML
    private TextField pass;

    @FXML
    private TextField pass2;


    @FXML
    private Button signupButton;
    Alert a = new Alert(Alert.AlertType.ERROR);
    static Donee d = new Donee();
    @FXML
    private Label labelem;

    @FXML
    private Label labelpa;
    @FXML
    private Label addero;
    @FXML
    private Label nameeror;

    @FXML
    private Label hello;

    @FXML
    private Label helloName;

    @FXML
    void brin(MouseEvent event) {
        helloName.textProperty().bind(F_name.textProperty());
    }



    @FXML
    void signupaction(ActionEvent event) throws IOException {

        Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<Donee> sList;
        Query query;
        query = session1.createQuery("from Donee");
        sList = query.list();
        session1.close();

        //chick if the email has already been used:
        for (Donee u : sList) {
            if (email.getText().equals(u.getEmail())) {
               labelem.setText("البريد الالكتروني مسجل بالفعل");
                return;
            }
            else
                labelem.setText("");

        }

        page:

        if(F_name.getText().isEmpty()&email.getText().isEmpty()&pass.getText().isEmpty()&add.getText().isEmpty()){

            a.setTitle("الحقول فارغة");
            a.setHeaderText(null);
            a.setContentText("من فضلك ادخل البيانات جميع الحقول مطلوبة");
            a.showAndWait();
        }

         else if(F_name.getText().isEmpty()){
            nameeror.setText("من فضلك ادخل الاسم");
        }
        else if (email.getText().isEmpty()) {
            labelem.setText("من فضلك ادخل البريد الالكتروني");
            nameeror.setText("");

        }

        else if (!(email.getText().matches("[a-zA-Z0-9][a-zA-Z0-9._]*@[gmail]+([.][com]+)+") || email.getText().matches("[a-zA-Z0-9][a-zA-Z0-9._]*@[windowslive]+([.][com]+)+") || email.getText().matches("[a-zA-Z0-9][a-zA-Z0-9._]*@[hotmail]+([.][com]+)+") || email.getText().matches("[a-zA-Z0-9][a-zA-Z0-9._]*@[outlook]+([.][com]+)+")))
        {
            labelem.setText("");

            a.setTitle("صيغة بريد الكتروني خاطئة");
            a.setHeaderText(null);
            a.setContentText("من فضلك ادخل صيغة بريد الكتروني صحيحة\n" +
                    "الصيغ المقبولة :\n" +
                    "\n\t\t-example@gmail.com \n\t\t-example@hotmail.com \n\t\t-example@outlook.com\n\t\t-example@windowslive.com.com");
            a.showAndWait();

        }

         else if (pass.getText().isEmpty()) {
             labelem.setText("");
             labelpa.setText("ادخل كلمة المرور");
         }

       else if (!pass2.getText().equals(pass.getText())) {
           do{
               labelpa.setText("من فضلك اعد ادخال كلمة المرور ");
           } while(pass2.getText().equals(pass.getText()));

        }

       else if(add.getText().isEmpty()){
            labelpa.setText("");
        addero.setText(" من فضلك ادخل العنوان");}

        else {
             labelpa.setText("");
             labelem.setText("");
             addero.setText("");
            d.setDoneeId((int) (Math.random() * (9999 - 1000 + 1) + 1000));
            d.setPass(pass.getText());
            d.setAddress(add.getText());
            d.setFirstName(F_name.getText());
            d.setLastName(L_name.getText());
            d.setEmail(email.getText());
            d.setPhoneNumber("1");

            User.setUseradd(add.getText());
            User.setUsername(F_name.getText());
            User.setUsernameL(L_name.getText());
            User.setUseremail(email.getText());
            User.setUserpassword(pass.getText());




            Transaction tx = null;
            Session session = HibernateUtil.getSessionFactory().openSession();
            try {
                tx = session.beginTransaction();
                int dI = (Integer) session.save(d);
                tx.commit();
            } catch (Exception e) {
                if (tx != null) {
                    tx.rollback();
                }
                e.printStackTrace();
            } finally {
                session.close();
            }
            System.out.println("inserted item: " + d.getFirstName());
            User.setId(d.getDoneeId());



            Parent root = FXMLLoader.load(getClass().getResource("/home.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle("Hello!");
            stage.setScene(scene);
            stage.show();
            //break page;
        }
    }}


