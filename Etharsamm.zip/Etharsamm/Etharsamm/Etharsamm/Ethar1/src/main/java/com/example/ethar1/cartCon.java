package com.example.ethar1;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.control.Button;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.FileChooser.ExtensionFilter;
import java.io.File;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.persistence.Query;

/**
 * FXML Controller class
 *
 * @author malia
 */
public class cartCon implements Initializable {
    @FXML
    private AnchorPane Ap;

    @FXML
    private Pane pane;

    @FXML
    private ScrollPane sp;

    @FXML
    private VBox parentVbox;

    @FXML
    private HBox HB1;

    @FXML
    private VBox vbgar;

    @FXML
    private Label itemId1;

    @FXML
    private ImageView gar1;

    @FXML
    private VBox vb4;

    @FXML
    private Text DT1;

    @FXML
    private Text ST1;

    @FXML
    private ImageView image1;

    @FXML
    private HBox HB2;

    @FXML
    private Label itemId2;

    @FXML
    private ImageView gar2;

    @FXML
    private VBox vb41;

    @FXML
    private Text DT2;

    @FXML
    private Text ST2;

    @FXML
    private ImageView image2;

    @FXML
    private HBox HB3;

    @FXML
    private VBox vbgar1;

    @FXML
    private Label itemId3;

    @FXML
    private ImageView gar3;

    @FXML
    private VBox vb42;

    @FXML
    private Text DT3;

    @FXML
    private Text sizeText3;

    @FXML
    private ImageView image3;

    @FXML
    private HBox HB4;

    @FXML
    private VBox vbgar2;

    @FXML
    private Label itemId4;

    @FXML
    private ImageView gar4;

    @FXML
    private VBox vb43;

    @FXML
    private Text DT4;

    @FXML
    private Text sizeText4;

    @FXML
    private ImageView image4;

    @FXML
    private HBox HB5
            ;

    @FXML
    private VBox vbgar3;

    @FXML
    private Label itemId5;

    @FXML
    private ImageView gar5;

    @FXML
    private VBox vb44;

    @FXML
    private Text DT5;

    @FXML
    private Text sizeText5;

    @FXML
    private ImageView image5;

    @FXML
    private Button backbut;
    @FXML
    private Parent root;

    @FXML
    private Stage stage;
    List <Item> itemsList = new ArrayList();
    Order1 order=new Order1();

    Cart cart=new Cart();

    public void initialize(URL url, ResourceBundle rb) {
        HB1.setVisible(false);
        HB2.setVisible(false);
        HB3.setVisible(false);
        HB4.setVisible(false);
        HB5.setVisible(false);

        Session session = HibernateUtil.getSessionFactory().openSession();
//        Query q1 = session.createQuery("from Item where ItemID= :itemId");
//        q1.setParameter("itemId", cart.getItemID());
//        List<Item> itemsList = q1.getResultList();

        Query q1 = session.createQuery("from Item where ItemID= :itemId");
        Query q2 = session.createQuery("from Cart");
        List<Cart> cartList = q2.getResultList();
        int iteration = 0;
        for(Cart cart: cartList) {
            q1.setParameter("itemId", cart.getItemID());
            Item s = (Item) q1.getSingleResult();
            iteration++;
            if(iteration==1){
                HB1.setVisible(true);
                image1.setImage(new Image(s.getImage()));
                itemId1.setText(String.valueOf(s.getItemID()));
                DT1.setText(s.getName());
                ST1.setText("المقاس:"+s.getSize());
            }
            else if(iteration==2){
                HB2.setVisible(true);
                image2.setImage(new Image(s.getImage()));
                itemId2.setText(String.valueOf(s.getItemID()));
                DT2.setText(s.getName());
                ST2.setText("المقاس:"+s.getSize());
            }
            else if(iteration==3){
                HB3.setVisible(true);
                image3.setImage(new Image(s.getImage()));
                itemId3.setText(String.valueOf(s.getItemID()));
                DT3.setText(s.getName());
                sizeText3.setText("المقاس:"+s.getSize());}
            else if(iteration==4){
                HB4.setVisible(true);
                image4.setImage(new Image(s.getImage()));
                itemId4.setText(String.valueOf(s.getItemID()));;
                DT4.setText(s.getName());
                sizeText4.setText("المقاس:"+s.getSize());
            }
            else if(iteration==5){
                HB5.setVisible(true);
                image5.setImage(new Image(s.getImage()));
                itemId5.setText(String.valueOf(s.getItemID()));
                DT5.setText(s.getName());
                sizeText5.setText("المقاس:"+s.getSize());
            }
        }
        session.close();
    }

    @FXML
    public void deleteItem1(){
        parentVbox.getChildren().remove(HB1);
        deleteItem(Integer.valueOf(itemId1.getText()));
        HB1.setVisible(false);

    }
    @FXML
    public void deleteItem2(){
        parentVbox.getChildren().remove(HB2);
        deleteItem(Integer.valueOf(itemId2.getText()));
        HB2.setVisible(false);

    }
    @FXML
    public void deleteItem3(){
        parentVbox.getChildren().remove(HB3);
        deleteItem(Integer.valueOf(itemId3.getText()));
        HB3.setVisible(false);

    }
    @FXML
    public void deleteItem4(){
        parentVbox.getChildren().remove(HB4);
        deleteItem(Integer.valueOf(itemId4.getText()));
        HB4.setVisible(false);
    }
    @FXML
    public void deleteItem5(){
        parentVbox.getChildren().remove(HB5);
        deleteItem(Integer.valueOf(itemId5.getText()));
        HB5.setVisible(false);
    }
    public boolean isEmpyy()throws IOException{
        if (HB1.isVisible()==false){
            return true;
        }
        return false;}
    public void processDone(ActionEvent event)throws IOException {
        if (isEmpyy() == true) {
            Alert alertInformation = new Alert(AlertType.ERROR);
            alertInformation.setHeaderText("عزيزي المستفيد : يرجى تعبئة السلم لإتمام الطلب");
            //alertInformation.setContentText("عزيزي المستفيد : تمت العملية بنجاح سيتم التواصل معك خلال 3 أيام✅");
            alertInformation.showAndWait();
        } else {

            // handleButtonAction() هنا قلنا أنه سيتم إنشاء نافذة صغيرة منبثقة كلما تم تنفيذ الدالة
            Alert alertInformation = new Alert(AlertType.CONFIRMATION);
            alertInformation.setHeaderText("عزيزي المستفيد : تمت العملية بنجاح سيتم التواصل معك خلال 3 أيام✅");
            alertInformation.showAndWait();

            Session session = HibernateUtil.getSessionFactory().openSession();
            Transaction transaction = session.beginTransaction();
                order.setOrderID((int) (Math.random() * (9999 - 1000 + 1) + 1000));
                order.setDoneeID(User.getId());
                session.save(order);
                transaction.commit();
                session.close();

            deleteItem1();
            deleteItem2();
            deleteItem3();
            deleteItem4();
            deleteItem5();
          /*  HB1.setVisible(false);
            HB2.setVisible(false);
            HB3.setVisible(false);
            HB4.setVisible(false);
            HB5.setVisible(false);*/


        }
    }

    @FXML
    void backbut(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/home.fxml"));
        stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public void increment(MouseEvent mouseEvent) {
    }

    public void deleteItem(int id){
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        Query q1 = session.createQuery("from Cart where Item_ID= :id");
        q1.setParameter("id", id);
        Cart cart = (Cart) q1.getSingleResult();
        session.remove(cart);
        transaction.commit();
        session.close();
    }
}