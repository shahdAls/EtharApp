package com.example.ethar1; /**
 * @author malia
 */

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

import javafx.scene.Parent;

public class Main extends Application {

    public void start(Stage stage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/start.fxml"));
        Scene scene = new Scene(root);
        //scene.getStylesheets().add("file:dark.css");
        stage.setTitle("Ethar");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        // TODO code application logic here
        launch(args);
    }

}
