package com.example.ethar1;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;

import java.io.IOException;

/**
 * FXML Controller class
 *
 * @author malia
 */
public class loginControlfordoner implements Initializable {

    @FXML
    private TextField emaillog;

    @FXML
    private Label emailnot;

    @FXML
    private Button login;

    @FXML
    private TextField passlog;

    @FXML
    private Label passnot;

    @FXML
    private Label signup;
    int id;

    @FXML
    public void signUp(MouseEvent mouseEvent) throws IOException {
      Parent  root = FXMLLoader.load(getClass().getResource("/signupdoner2.fxml"));
      Stage  stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();

    }
    @FXML
    public void logindoner(MouseEvent mouseEvent) throws IOException {

        Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<Donor> sList;
        Query query;
        query = session1.createQuery("from Donor ");
        sList = query.list();
        session1.close();
        for (Donor u : sList) {
            u.getEmail();
            u.getPassword();
        }
        //chick if the email has been used:
        for (Donor u : sList) {
            if (emaillog.getText().equals(u.getEmail()) &&passlog.getText().equals(u.getPassword())) {
                id= u.getDonorId();
                DonorController.initData(u);
                Parent root = FXMLLoader.load(getClass().getResource("/donor.fxml"));
                Stage stage= (Stage)((Node)mouseEvent.getSource()).getScene().getWindow();
                Scene scene = new Scene(root);
                stage.setTitle("Hello!");
                stage.setScene(scene);
                stage.show();
            }
            else {
                if((!emaillog.getText().equals(u.getEmail()))) {
                    emailnot.setText("البريد الالكتروني غير مسجل");
                }

                else{
                    emailnot.setText("البريد الالكتروني غير مسجل");
                    passnot.setText("كلمة المرور غير صحيحة");
                }

            }

        }

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //To change body of generated methods, choose Tools | Templates.
    }
}
