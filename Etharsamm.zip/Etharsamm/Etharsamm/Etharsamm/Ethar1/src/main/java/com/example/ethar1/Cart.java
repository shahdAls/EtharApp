package com.example.ethar1;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cart")
public class Cart implements java.io.Serializable {
    @Id
    @Column(name = "cartId")
    private int cartId;

    @Column(name = "Item_ID")
    private int Item_ID;

    public Cart() {
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public int getItemID() {
        return Item_ID;
    }

    public void setItemID(int item_ID) {
        Item_ID = item_ID;
    }
}