package com.example.ethar1;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.IOException;



/**
 * FXML Controller class
 *
 * @author malia
 */
public class PesonalfileController implements Initializable {
    
    @FXML
    private ImageView home;

    @FXML
    private Label label1;

    @FXML
    private Label label2;

    @FXML
    private Label label3;

    @FXML
    private Label label4;

    @FXML
    private TextField label5;

    @FXML
    private Label label6;

    @FXML
    private Parent root;
    @FXML
    private Label numerla;

    @FXML
    private Stage stage;


    @FXML
    void home(MouseEvent event) throws IOException {



        root = FXMLLoader.load(getClass().getResource("/home.fxml"));
        stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }



    @FXML
    void check(KeyEvent event)  throws IOException {
        if(event.getCode()== KeyCode.ENTER){
        if (label5.getText().equals("")) {
            numerla.setText("من فضلك ادخل الرقم");
        } else if (!label5.getText().matches("^[0-9]+$")) {
            numerla.setText("من فضلك ادخل رقما صحيحاً");
        } else if (label5.getText().length() != 10) {
            numerla.setText("من فضلك يجب ان يكون الرقم مكون من10  ارقام");
        } else {


            //signupControlfordonee.d.setPhoneNumber(label5.getText());

            numerla.textProperty().bind(label5.textProperty());
            /*List<Donee> sList;

            Query query;
            Session session1 = HibernateUtil.getSessionFactory().openSession();
            query = session1.createQuery("from Donee");
            sList = query.list();
            session1.close();*/

            //chick if the email has already been used:
         //   for (Donee u : sList) {
                //if (u.getDoneeId() == User.getId()) {
                    //d.setPhoneNumber(label5.getText());
                }


            }else
            System.out.println("error");}





    @Override
    public void initialize(URL url, ResourceBundle rb) {
        label1.setText(User.getUsername());
        label2.setText(User.getUsernameL());
        label3.setText(User.getUseremail());
        label4.setText(User.getUseradd());
        label6.setText(User.getUserpassword());


    }
    
}
