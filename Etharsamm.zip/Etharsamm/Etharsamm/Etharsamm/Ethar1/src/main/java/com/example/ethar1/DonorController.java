package com.example.ethar1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.persistence.Query;
import java.io.IOException;
import java.util.List;


/**
 * FXML Controller class
 *
 * @author Lina Alrefi
 */
public class DonorController  {


    @FXML
    private TextField chooserlbl;
    @FXML
    private Button fileChooserBt;
    @FXML
    private RadioButton manRb;
    @FXML
    private RadioButton womenRb;
    @FXML
    private RadioButton kidsRb;
    @FXML
    private RadioButton pantsRb;
    @FXML
    private RadioButton blouseRb;
    @FXML
    private RadioButton shoseRb;
    @FXML
    private RadioButton dressRb;
    @FXML
    private RadioButton thoobRb;
    @FXML
    private ComboBox<String> comboBox = new ComboBox<>();
    @FXML
    private TextField nameField;
    @FXML
    ToggleGroup typeToggleGroup = new ToggleGroup();
    private String gender1;
    @FXML
    ObservableList<String> size1 = FXCollections.observableArrayList("Small", "Medium", "Large","X Large","XX Large");
    @FXML
    ObservableList<String> AdultsShoeSise = FXCollections.observableArrayList("35","36","37","38","39","40","41");
    @FXML
    ObservableList<String> thobManSize = FXCollections.observableArrayList("52","54","56","58","60","62");
    @FXML
    ObservableList<String> kidsSize = FXCollections.observableArrayList("1-6 Month","1-2 year","3-4 year","4-5 year",
            "5-6 year","6-7 year","7-8 year","8-9 year","9-10 year","10-11 year","11-12 year","12-13 year","13-14 year");
    @FXML
    ObservableList<String> kidsShoseSise = FXCollections.observableArrayList("1 year","2  year","24","25","26","27","28","29","30","31","32","33","34");
    @FXML
    private Button submit;
    String link;
    @FXML
    private TextArea description;
    private String category;

    @FXML
    private Label errorLabel;
    @FXML
    private Label newItemLabel;

    private static Donor donor;

    static void initData(Donor ldonor) {
        donor = ldonor;
    }


    @FXML
    public void handleType (ActionEvent event){
        if (manRb.isSelected() && dressRb.isSelected()){errorLabel.setText("من فضلك ادخل البيانات بشكل صحيح");}
        if(blouseRb.isSelected()){category="shirt";}
        else if (dressRb.isSelected() ) {category="dress";}
        else if (thoobRb.isSelected()) {category="thob";}
        else if (pantsRb.isSelected()) {category="pants";}
        else if (shoseRb.isSelected()){category="shoes";}

        if (((blouseRb.isSelected()|| dressRb.isSelected()|| thoobRb.isSelected()) && womenRb.isSelected())|| ((womenRb.isSelected() || manRb.isSelected()) & (pantsRb.isSelected() || blouseRb.isSelected() ) )) {
            comboBox.getItems().clear();
            comboBox.getItems().addAll(size1);

        } else if ( womenRb.isSelected() && shoseRb.isSelected() ) {
            comboBox.getItems().clear();
            comboBox.getItems().addAll(AdultsShoeSise);
        }else if (manRb.isSelected() & dressRb.isSelected() ) {
            comboBox.getItems().clear();
        }else if ( manRb.isSelected() && shoseRb.isSelected() ) {
            comboBox.getItems().clear();
            comboBox.getItems().addAll(AdultsShoeSise);
            comboBox.getItems().addAll("42", "43", "44", "45");
        }else if ( manRb.isSelected() && thoobRb.isSelected() ) {
            comboBox.getItems().clear();
            comboBox.getItems().addAll(thobManSize);

        }else if ( kidsRb.isSelected() && (thoobRb.isSelected() || pantsRb.isSelected()||blouseRb.isSelected()||dressRb.isSelected() )) {
            comboBox.getItems().clear();
            comboBox.getItems().addAll(kidsSize);
        }else if ( kidsRb.isSelected() && shoseRb.isSelected() ) {
            comboBox.getItems().clear();
            comboBox.getItems().addAll(kidsShoseSise);
        }



    };

    @FXML
    public void handleFileChooser (ActionEvent event){
        Stage primaryStage = new Stage();

        FileChooser fileChooser = new FileChooser();

        // Set the extension filter to only allow image files
        FileChooser.ExtensionFilter imageFilter = new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif");
        fileChooser.getExtensionFilters().add(imageFilter);

        // Show the file chooser dialog and get the selected file
        java.io.File selectedFile = fileChooser.showOpenDialog(primaryStage);

        if (selectedFile != null) {
            System.out.println("Selected image: " + selectedFile.getAbsolutePath());
            chooserlbl.setText(selectedFile.getAbsolutePath());
            link = selectedFile.getAbsolutePath();

        }

    }

    public void setManRb(ActionEvent event) {
        if(manRb.isSelected()){gender1="Men";}
    }

    public void setFemaleRb(ActionEvent event) {
        if(womenRb.isSelected()){gender1="Women";}
    }

    public void setKidsRb(ActionEvent event) {
        if(kidsRb.isSelected()){gender1="Children";}
    }

    @FXML
    public void submitHandler(ActionEvent event) {submit();}






    @FXML
    public void newItemHandler(MouseEvent mouseEvent) {clear();}

    @FXML
    public void deleteHandler(KeyEvent keyEvent) {
        if(keyEvent.getCode() == KeyCode.DELETE){clear();}}

    public void clear() {
        comboBox.setValue("");
        errorLabel.setText("");
        chooserlbl.setText("");
        nameField.setText("");
        description.setText(null);
        if (manRb.isSelected()) {
            manRb.setSelected(false);
        } else if (womenRb.isSelected()) {
            womenRb.setSelected(false);
        } else if (kidsRb.isSelected()) {
            kidsRb.setSelected(false);
        }
        switch (category) {
            case "shirt":
                blouseRb.setSelected(false);
                break;
            case "dress":
                dressRb.setSelected(false);
                break;
            case "thob":
                thoobRb.setSelected(false);
                break;
            case "shoes":
                shoseRb.setSelected(false);
                break;
            case "pants":
                pantsRb.setSelected(false);
                break;
            default:
                break;
        }

    }
    public void submit(){
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Item item1 = new Item();
        item1.setImage(link);
        item1.setName(nameField.getText());
        item1.setSize(comboBox.getValue());
        item1.setDescrip(description.getText());


        Query q1 = session.createQuery("from Category where Section= :section AND Type1= :type");
        q1.setParameter("section", gender1);
        q1.setParameter("type", category);
        Category category1 = (Category) q1.getSingleResult();
        item1.setCategory(category1);
        //item1.setDonorID(donor);

        if (item1.getImage()== null) {errorLabel.setText("من فضلك ارفق صورة للقطعة المتبرع بها");}
        else if(gender1== null){errorLabel.setText("من فضلك قم باختيار الفئة");}
        else if (category== null){errorLabel.setText("من فضلك قم باختيار النوع");}
        else if (nameField.getText().equals("")) {errorLabel.setText("من فضلك أدخل اسم القطعة");}
        else if (item1.getSize()==null) {errorLabel.setText("من فضلك قم باختيار المقاس");}
        else if (description.getText().equals("")) {errorLabel.setText("من فضلك اكتب وصف مختصر للقطعة");}
        else{
              item1.setDonorID(donor);
              // item1.setCategoryID(gender1,category);
            errorLabel.setText("");
            session.save(item1);
            transaction.commit();
            session.close();
            System.out.println("inserted item: " + item1.getItemID());
            newItemLabel.setText("للتبرع بقطعة اخرى أنقر هنا");
        }

    }


    public void end(MouseEvent mouseEvent) throws IOException {

        Parent women = FXMLLoader.load(getClass().getResource("/Ending.fxml"));
        Scene womenscene = new Scene(women);
        Stage stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        stage.setScene(womenscene);
        stage.show();

    }
}





