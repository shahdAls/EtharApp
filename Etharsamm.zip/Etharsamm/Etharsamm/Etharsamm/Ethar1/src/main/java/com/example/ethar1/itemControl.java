
package com.example.ethar1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.persistence.Query;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class itemControl implements Initializable {

    @FXML
    private Label Desc;
 static int x=0;
    @FXML
    private Image Img;

    @FXML
    private Button Size;

    @FXML
    private Button backbut;

    @FXML
    private Label counter;

    @FXML
    private ImageView mainImg;

    @FXML
    private Label num;
    @FXML
    private Label labelAlarm;
    @FXML
    private Label numbers;


    @FXML
    private Button sizeButton;
    @FXML
    private Label desc;

    private
    @FXML
    void backbut(ActionEvent event) throws IOException {
        if (itemButton.womenButton==true){

            Parent root = FXMLLoader.load(getClass().getResource("/women.fxml"));
            Stage stage= (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle("Hello!");
            stage.setScene(scene);
            stage.show();
        }
        else if (itemButton.menButton==true){

            Parent root = FXMLLoader.load(getClass().getResource("/men.fxml"));
            Stage   stage= (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle("Hello!");
            stage.setScene(scene);
            stage.show();
        }
        else {
            Parent root = FXMLLoader.load(getClass().getResource("/kids.fxml"));
            Stage stage= (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle("Hello!");
            stage.setScene(scene);
            stage.show();

        }
    }



    private static Item item;

    static void initData(Item items) {
        item = items;
    }

    @FXML
    void sizeChooser(ActionEvent event) {
        num.setTextFill(Color.rgb(199,153,56));

    }

  //  @FXML
    //void increment(MouseEvent event) {


  //  }

    @FXML
    public void initialize(URL url, ResourceBundle rb) {
        numbers.setText(item.getSize());
        desc.setText(item.getDescrip());
        mainImg.setImage(new Image(item.getImage()));
    }


    @FXML
    void addToCart(ActionEvent event) throws IOException {
        if(x<5){
            ++x;
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        if(item.getAvailability()){

            Cart cart = new Cart();
            cart.setCartId((int) (Math.random() * (9999 - 1000 + 1) + 1000));
            cart.setItemID(item.getItemID());
            session.save(cart);
            transaction.commit();
            session.close();

            Parent root = FXMLLoader.load(getClass().getResource("/cart.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene signupdo = new Scene(root);
            stage.setTitle("Hello!");
            stage.setScene(signupdo);
            stage.show();

        }
        else{
            Alert alertInformation = new Alert(Alert.AlertType.ERROR);
            alertInformation.setHeaderText("القطعة غير متوافرة");
            alertInformation.showAndWait();
        }

    }
        else{
            Alert alertInformation = new Alert(Alert.AlertType.ERROR);
          alertInformation.setHeaderText("عزيزي المستفيد لايمكنك إضافة اكثر من خمسة عناصر");
            alertInformation.showAndWait();
        }
    }

}