module com.example.ethar1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.naming;
    requires java.sql;
    requires org.hibernate.orm.core;
    requires java.persistence;
    opens com.example.ethar1 to javafx.fxml,org.hibernate.orm.core;
    exports com.example.ethar1;
}