package com.example.ethar1;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * FXML Controller class
 *
 * @author malia
 */
public class ChoControl implements Initializable {
   
    @FXML
    public void donner(MouseEvent event) throws IOException {
        Parent logd = FXMLLoader.load(getClass().getResource("/logindoner.fxml"));
        Scene logScened = new Scene(logd);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(logScened);
        stage.show();

    }

    @FXML
    public void donee(MouseEvent event) throws IOException {
        Parent log = FXMLLoader.load(getClass().getResource("/log.fxml"));
        Scene logScene = new Scene(log);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(logScene);
        stage.show();


    }


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
