package com.example.ethar1;

import javax.persistence.*;

@Entity
@Table(name = "order1")
public class Order1 implements java.io.Serializable {
    @Id
    @Column(name = "OrderID")
    private int OrderID;


    @Column(name = "DoneeID")
    private int DoneeID;




    public int getOrderID() {
        return OrderID;
    }



    public void setOrderID(int orderID) {
        OrderID = orderID;
    }



    public int getDoneeID() {
        return DoneeID;
    }

    public void setDoneeID(int doneeID) {
        DoneeID = doneeID;
    }



}
