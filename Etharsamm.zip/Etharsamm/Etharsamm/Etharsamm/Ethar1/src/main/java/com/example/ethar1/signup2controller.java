package com.example.ethar1;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @author malia
 */

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.IOException;
import java.util.List;

public class signup2controller {

    Alert a = new Alert(Alert.AlertType.ERROR);
    Donor donor = new Donor();
    @FXML
    private TextField F_name2;
    @FXML
    private TextField L_name2;
    @FXML
    private TextField add2;
    @FXML
    private TextField email2;
    @FXML
    private Label labelEma2;
    @FXML
    private Label labelPass2;
    @FXML
    private TextField pass2d;
    @FXML
    private TextField passd;
    @FXML
    private Button signupBut;
    @FXML
    private Label adderor2;
    @FXML
    private Label nameError;

    @FXML
    private Label hello2;

    @FXML
    private Label helloName2;

    @FXML
    void brin(MouseEvent event) {
            helloName2.textProperty().bind(F_name2.textProperty());
    }

    @FXML
    void signupact2(ActionEvent event) throws IOException {
        Session session1 = HibernateUtil.getSessionFactory().openSession();
        List<Donor> sList;
        Query query;
        query = session1.createQuery("from Donor");
        sList = query.list();
        session1.close();

        //chick if the email has already been used:
        for (Donor u : sList) {
            if (email2.getText().equals(u.getEmail())) {
                labelEma2.setText("البريد الالكتروني مسجل بالفعل");
                return;
            } else
                labelEma2.setText("");

        }
        page:


        if (F_name2.getText().isEmpty() & email2.getText().isEmpty() & passd.getText().isEmpty() & add2.getText().isEmpty()) {

            a.setTitle("الحقول فارغة");
            a.setHeaderText(null);
            a.setContentText("من فضلك ادخل البيانات جميع الحقول مطلوبة");
            a.showAndWait();
        } else if (F_name2.getText().isEmpty()) {
            nameError.setText("من فضلك ادخل الاسم");
        } else if (email2.getText().isEmpty()) {
            labelEma2.setText("من فضلك ادخل البريد الالكتروني");
           nameError.setText("");


        }


        else if (!(email2.getText().matches("[a-zA-Z0-9][a-zA-Z0-9._]*@[gmail]+([.][com]+)+") || email2.getText().matches("[a-zA-Z0-9][a-zA-Z0-9._]*@[windowslive]+([.][com]+)+") || email2.getText().matches("[a-zA-Z0-9][a-zA-Z0-9._]*@[hotmail]+([.][com]+)+") || email2.getText().matches("[a-zA-Z0-9][a-zA-Z0-9._]*@[outlook]+([.][com]+)+"))) {
            labelEma2.setText("");

            a.setTitle("صيغة بريد الكتروني خاطئة");
            a.setHeaderText(null);
            a.setContentText("من فضلك ادخل صيغة بريد الكتروني صحيحة\n" +
                    "الصيغ المقبولة :\n" +
                    "\n\t\t-example@gmail.com \n\t\t-example@hotmail.com \n\t\t-example@outlook.com\n\t\t-example@windowslive.com.com");
            a.showAndWait();
        } else if (passd.getText().isEmpty()) {
            labelPass2.setText("ادخل كلمة المرور");
            labelEma2.setText("");
        } else if (!pass2d.getText().equals(passd.getText())) {
            do {
                labelPass2.setText("اعد ادخال كلمة المرور ");
            }
            while (pass2d.getText().equals(passd.getText()));
        } else if (add2.getText().isEmpty()) {
            adderor2.setText(" من فضلك ادخل العنوان");
            labelPass2.setText("");

        } else {
            donor.setDonorId((int) (Math.random() * (9999 - 1000 + 1) + 1000));
            donor.setPassword(passd.getText());
            donor.setAddress(add2.getText());
            donor.setFirstName(F_name2.getText());
            donor.setLastName(L_name2.getText());
            donor.setEmail(email2.getText());

            User.setUseradd(add2.getText());
            User.setUsername(F_name2.getText());
            User.setUsernameL(L_name2.getText());
            User.setUseremail(email2.getText());
            User.setUserpassword(passd.getText());


            labelEma2.setText("");
            labelPass2.setText("");
            nameError.setText("");
            adderor2.setText("");


            Transaction tx = null;
            Session session = HibernateUtil.getSessionFactory().openSession();
            try {
                tx = session.beginTransaction();
                int dI = (Integer) session.save(donor);
                tx.commit();
            } catch (Exception e) {
                if (tx != null) {
                    tx.rollback();
                }
                e.printStackTrace();
            } finally {
                session.close();
            }
            System.out.println("inserted item: " + donor.getFirstName());
            User.setId(donor.getDonorId());
            System.out.println("inserted item: " + donor.getDonorId());



            Parent root = FXMLLoader.load(getClass().getResource("/donor.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene signupdo = new Scene(root);
            stage.setTitle("Hello!");
            stage.setScene(signupdo);
            stage.show();
            //break page;
        }

    }
}
