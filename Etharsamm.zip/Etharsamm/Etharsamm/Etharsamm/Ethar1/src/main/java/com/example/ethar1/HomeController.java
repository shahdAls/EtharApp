package com.example.ethar1;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HomeController implements Initializable {

    @FXML
    private ImageView image1;

    @FXML
    private ImageView image2;

    @FXML
    private ImageView image3;

    @FXML
    private ImageView image4;

    @FXML
    private ImageView image5;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Button basket;

    @FXML
    private Parent root;

    @FXML
    private Stage stage;

    @FXML
    private Button home;

    @FXML
    private Button personprofile;

    public void slider() {

        new Thread(){
        public void run(){
            int count =0;
            try {


                while (true) {
                    switch (count) {
                        case 0:
                            Thread.sleep(3000);
                            TranslateTransition slider1=new  TranslateTransition();
                            slider1.setNode(image1);
                            slider1.setDuration(Duration.seconds(10));
                            slider1.setToX(800);
                            slider1.play();

                            TranslateTransition slider2=new  TranslateTransition();
                            slider2.setNode(image2);
                            slider2.setDuration(Duration.seconds(10));
                            slider2.setToX(600);
                            slider2.play();

                            TranslateTransition slider3=new  TranslateTransition();
                            slider3.setNode(image3);
                            slider3.setDuration(Duration.seconds(10));
                            slider3.setToX(400);
                            slider3.play();



                            TranslateTransition slider4=new  TranslateTransition();
                            slider4.setNode(image5);
                            slider4.setDuration(Duration.seconds(10));
                            slider4.setToX(300);
                            slider4.play();


                            count=1;
                            break;
                        case 1:


                            Thread.sleep(9000);
                            TranslateTransition slider5=new  TranslateTransition();
                            slider5.setNode(image1);
                            slider5.setDuration(Duration.seconds(10));
                            slider5.setToX(-100);
                            slider5.play();

                            TranslateTransition slider6=new  TranslateTransition();
                            slider6.setNode(image2);
                            slider6.setDuration(Duration.seconds(10));
                            slider6.setToX(-80);
                            slider6.play();

                            TranslateTransition slider7=new  TranslateTransition();
                            slider7.setNode(image3);
                            slider7.setDuration(Duration.seconds(10));
                            slider7.setToX(-50);
                            slider7.play();



                            TranslateTransition slider8=new  TranslateTransition();
                            slider8.setNode(image5);
                            slider8.setDuration(Duration.seconds(10));
                            slider8.setToX(0);
                            slider8.play();
                            count=0;



                            break;




                }
                }


            } catch (Exception e){e.printStackTrace();}

        }
        }
        .start();
    }

    public void initialize (URL url, ResourceBundle rb){
        slider();

    }

    public void women (MouseEvent mouseEvent) throws IOException {
        Parent women = FXMLLoader.load(getClass().getResource("/women.fxml"));
        Scene womenscene = new Scene(women);
        Stage stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        stage.setScene(womenscene);
        stage.show();
    
    }

    public void men(MouseEvent mouseEvent)throws IOException {
        Parent men = FXMLLoader.load(getClass().getResource("/men.fxml"));
        Scene menScene = new Scene(men);
        Stage stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        stage.setScene(menScene);
        stage.show();
    }

    public void kids(MouseEvent mouseEvent)throws IOException {
        Parent kids= FXMLLoader.load(getClass().getResource("/kids.fxml"));
        Scene kidsScene = new Scene(kids);
        Stage stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        stage.setScene(kidsScene);
        stage.show();
    }

    public void home(MouseEvent mouseEvent)throws IOException {
            Parent home= FXMLLoader.load(getClass().getResource("/home.fxml"));
            Scene homeScene = new Scene(home);
            Stage stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
            stage.setScene(homeScene);
            stage.show();
    }

    @FXML
    void personfile(MouseEvent event) throws IOException {
        Parent home= FXMLLoader.load(getClass().getResource("/pesonalfile.fxml"));
        Scene homeScene = new Scene(home);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(homeScene);
        stage.show();
    }

    public void cart(MouseEvent mouseEvent) throws IOException{
       /* Parent cart= FXMLLoader.load(getClass().getResource("cart.fxml"));
        Scene cartScene = new Scene(cart);
        Stage stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        stage.setScene(cartScene);
        stage.show();*/
    }

    @FXML
    void basket(MouseEvent mouseEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/cart.fxml"));
        stage= (Stage)((Node)mouseEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    void image3section(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/kids.fxml"));
        stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void image5section(MouseEvent event) throws IOException{
        Parent women = FXMLLoader.load(getClass().getResource("/kids.fxml"));
        Scene womenscene = new Scene(women);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(womenscene);
        stage.show();
    }

    @FXML
    void pantsSection(MouseEvent event) throws IOException {
        Parent women = FXMLLoader.load(getClass().getResource("/women.fxml"));
        Scene womenscene = new Scene(women);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(womenscene);
        stage.show();

    }
    @FXML
    void shirtSection(MouseEvent event) throws IOException{
        Parent women = FXMLLoader.load(getClass().getResource("/men.fxml"));
        Scene womenscene = new Scene(women);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(womenscene);
        stage.show();

    }

}
