package com.example.ethar1;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

/**
 * FXML Controller class
 *
 * @author malia
 */
public class WomenController implements Initializable {
    @FXML
    private Button BackBut;

    @FXML
    private ImageView baskit;

    @FXML
    private ImageView imagemenu;

    @FXML
    private ImageView img;

    @FXML
    private ImageView item1;

    @FXML
    private ImageView item2;

    @FXML
    private ImageView item3;

    @FXML
    private ImageView item4;

    @FXML
    private ImageView item5;

    @FXML
    private ImageView item6;

    @FXML
    private ImageView menrect1;

    @FXML
    private ImageView menrect2;

    @FXML
    private ImageView menrect3;

    @FXML
    private ImageView menrect4;

    @FXML
    private ImageView menrect5;

    @FXML
    private VBox menu;

    @FXML
    private Text txt1;

    @FXML
    private Text txt2;

    @FXML
    private Text txt3;

    @FXML
    private Text txt4;

    @FXML
    private Text txt5;

    @FXML
    private Text txt6;

    @FXML
    private Parent root;

    @FXML
    private Stage stage;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        String queryStr = "from Item where CategoryID=4";
        Query query = session.createQuery(queryStr);
        iList = query.list();
        itemss.setAll(iList);
        session.close();
        int i=0;
        for(Item s: itemss)
        {

            if(i==0){
                item1.setImage(new Image(s.getImage()));
                txt1.setText(s.getName());}
            else if(i==1){
                item2.setImage(new Image(s.getImage()));
                txt2.setText(s.getName());}
            else if(i==2){
                item3.setImage(new Image(s.getImage()));
                txt3.setText(s.getName());}
            else if(i==3){
                item4.setImage(new Image(s.getImage()));
                txt4.setText(s.getName());}
            else if(i==4){
                item5.setImage(new Image(s.getImage()));
                txt5.setText(s.getName());}
            else if(i==5){
                item6.setImage(new Image(s.getImage()));
                txt6.setText(s.getName());}

            i++;

        }
    }
    @FXML
    void BackBut(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/home.fxml"));
        stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    private void basket(MouseEvent event) throws IOException {
        Parent women = FXMLLoader.load(getClass().getResource("/cart.fxml"));
        Scene womenscene = new Scene(women);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(womenscene);
        stage.show();
    }

    static List<Item> iList = null;
    ObservableList<Item> itemss= FXCollections.observableArrayList();
    @FXML
    void showItems2(MouseEvent event) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        String queryStr = "from Item where CategoryID=4";
        Query query = session.createQuery(queryStr);
        iList = query.list();
        itemss.setAll(iList);
        session.close();
        int i=0;
        for(Item s: itemss)
        {

            if(i==0){
                item1.setImage(new Image(s.getImage()));
                txt1.setText(s.getName());}
            else if(i==1){
                item2.setImage(new Image(s.getImage()));
                txt2.setText(s.getName());}
            else if(i==2){
                item3.setImage(new Image(s.getImage()));
                txt3.setText(s.getName());}
            else if(i==3){
                item4.setImage(new Image(s.getImage()));
                txt4.setText(s.getName());}
            else if(i==4){
                item5.setImage(new Image(s.getImage()));
                txt5.setText(s.getName());}
            else if(i==5){
                item6.setImage(new Image(s.getImage()));
                txt6.setText(s.getName());}

            i++;

        }
    }

    @FXML
    void showitems1(MouseEvent event) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        String queryStr = "from Item where CategoryID=2";
        Query query = session.createQuery(queryStr);
        iList = query.list();
        itemss.setAll(iList);
        session.close();
        int i=0;
        for(Item s: itemss)
        {

            if(i==0){
                item1.setImage(new Image(s.getImage()));
                txt1.setText(s.getName());}
            else if(i==1){
                item2.setImage(new Image(s.getImage()));
                txt2.setText(s.getName());}
            else if(i==2){
                item3.setImage(new Image(s.getImage()));
                txt3.setText(s.getName());}
            else if(i==3){
                item4.setImage(new Image(s.getImage()));
                txt4.setText(s.getName());}
            else if(i==4){
                item5.setImage(new Image(s.getImage()));
                txt5.setText(s.getName());}
            else if(i==5){
                item6.setImage(new Image(s.getImage()));
                txt6.setText(s.getName());}

            i++;

        }
    }

    @FXML
    void showitems3(MouseEvent event) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        String queryStr = "from Item where CategoryID=3";
        Query query = session.createQuery(queryStr);
        iList = query.list();
        itemss.setAll(iList);
        session.close();
        int i=0;
        for(Item s: itemss)
        {

            if(i==0){
                item1.setImage(new Image(s.getImage()));
                txt1.setText(s.getName());}
            else if(i==1){
                item2.setImage(new Image(s.getImage()));
                txt2.setText(s.getName());}
            else if(i==2){
                item3.setImage(new Image(s.getImage()));
                txt3.setText(s.getName());}
            else if(i==3){
                item4.setImage(new Image(s.getImage()));
                txt4.setText(s.getName());}
            else if(i==4){
                item5.setImage(new Image(s.getImage()));
                txt5.setText(s.getName());}
            else if(i==5){
                item6.setImage(new Image(s.getImage()));
                txt6.setText(s.getName());}

            i++;

        }
    }
    @FXML
    void showitems4(MouseEvent event) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        String queryStr = "from Item where CategoryID=1";
        Query query = session.createQuery(queryStr);
        iList = query.list();
        itemss.setAll(iList);
        session.close();
        int i=0;
        for(Item s: itemss)
        {

            if(i==0){
                item1.setImage(new Image(s.getImage()));
                txt1.setText(s.getName());}
            else if(i==1){
                item2.setImage(new Image(s.getImage()));
                txt2.setText(s.getName());}
            else if(i==2){
                item3.setImage(new Image(s.getImage()));
                txt3.setText(s.getName());}
            else if(i==3){
                item4.setImage(new Image(s.getImage()));
                txt4.setText(s.getName());}
            else if(i==4){
                item5.setImage(new Image(s.getImage()));
                txt5.setText(s.getName());}
            else if(i==5){
                item6.setImage(new Image(s.getImage()));
                txt6.setText(s.getName());}

            i++;

        }
    }

    @FXML
    void showitems5(MouseEvent event) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        String queryStr = "from Item where CategoryID=12";
        Query query = session.createQuery(queryStr);
        iList = query.list();
        itemss.setAll(iList);
        session.close();
        int i=0;
        for(Item s: itemss)
        {

            if(i==0){
                item1.setImage(new Image(s.getImage()));
                txt1.setText(s.getName());}
            else if(i==1){
                item2.setImage(new Image(s.getImage()));
                txt2.setText(s.getName());}
            else if(i==2){
                item3.setImage(new Image(s.getImage()));
                txt3.setText(s.getName());}
            else if(i==3){
                item4.setImage(new Image(s.getImage()));
                txt4.setText(s.getName());}
            else if(i==4){
                item5.setImage(new Image(s.getImage()));
                txt5.setText(s.getName());}
            else if(i==5){
                item6.setImage(new Image(s.getImage()));
                txt6.setText(s.getName());}

            i++;
        }
    }

    @FXML
    void showMinue(MouseEvent event) {
        if(event.isDragDetect())
            if(menu.isVisible())
            {menu.setVisible(false);
                imagemenu.setVisible(false);}
            else
            { menu.setVisible(true);
                imagemenu.setVisible(true);}
    }

    public void setData(Item item) {
        itemControl.initData(item);
    }
    @FXML
    void item1pic(MouseEvent event) throws IOException {
        itemButton.kidsButton=false;
        itemButton.womenButton=true;
        itemButton.menButton=false;
        setData(iList.get(0));
        root = FXMLLoader.load(getClass().getResource("/items.fxml"));
        stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void item2pic(MouseEvent event) throws IOException {
        itemButton.kidsButton=false;
        itemButton.womenButton=true;
        itemButton.menButton=false;
        setData(iList.get(1));
        root = FXMLLoader.load(getClass().getResource("/items.fxml"));
        stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void item3pic(MouseEvent event) throws IOException {
        itemButton.kidsButton=false;
        itemButton.womenButton=true;
        itemButton.menButton=false;
        setData(iList.get(2));
        root = FXMLLoader.load(getClass().getResource("/items.fxml"));
        stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void item4pic(MouseEvent event) throws IOException {
        itemButton.kidsButton=false;
        itemButton.womenButton=true;
        itemButton.menButton=false;
        setData(iList.get(3));
        root = FXMLLoader.load(getClass().getResource("/items.fxml"));
        stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void item5pic(MouseEvent event) throws IOException {
        itemButton.kidsButton=false;
        itemButton.womenButton=true;
        itemButton.menButton=false;
        setData(iList.get(4));
        root = FXMLLoader.load(getClass().getResource("/items.fxml"));
        stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void item6pic(MouseEvent event) throws IOException {
        itemButton.kidsButton=false;
        itemButton.womenButton=true;
        itemButton.menButton=false;
        setData(iList.get(5));
        root = FXMLLoader.load(getClass().getResource("/items.fxml"));
        stage= (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }
}



/**
 * Initializes the controller class.
 */
